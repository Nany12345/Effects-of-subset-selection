classdef HypE3N < ALGORITHM
% <multi/many> <real/binary/permutation>
% Hypervolume estimation algorithm
% nSample --- 10000 --- Number of sampled points for HV estimation

%------------------------------- Reference --------------------------------
% J. Bader and E. Zitzler, HypE: An algorithm for fast hypervolume-based
% many-objective optimization, Evolutionary Computation, 2011, 19(1):
% 45-76.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2022 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    methods
        function main(Algorithm,Problem)
            %% Parameter setting
            nSample = Algorithm.ParameterSet(10000);

            %% Generate random population
            Population = Problem.Initialization();
            Z = min(Population.objs,[],1);
            % Reference point for hypervolume calculation
            RefPoint = zeros(1,Problem.M) + 2000;

            %% Optimization
            while Algorithm.NotTerminated(Population)
                % Normalize
                PopObj = Population.objs;
                FrontNo = NDSort(PopObj,Problem.N+1);
                Zmax   = max(PopObj(FrontNo==1,:),[],1);
                a      = Zmax - Z + 1e-6;
                PopObj_translated = PopObj - Z;
                PopObj_normalized = PopObj_translated./a;

                MatingPool = TournamentSelection(2,Problem.N,-CalHV(PopObj_normalized,RefPoint,Problem.N,nSample));
                Offspring  = OperatorGA(Population(MatingPool));
                [Population,Z] = EnvironmentalSelection3([Population,Offspring],Problem.N,RefPoint,nSample,Z);
            end
        end
    end
end

function [Population,Z] = EnvironmentalSelection3(Population,N,RefPoint,nSample,Z)
% The environmental selection of HypE

%------------------------------- Copyright --------------------------------
% Copyright (c) 2022 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    %% Non-dominated sorting
    [FrontNo,MaxFNo] = NDSort(Population.objs,N);
    Next = FrontNo < MaxFNo;

    %% Normalization
    PopObj = Population.objs;
    Z = min([Z; PopObj],[],1);
    Zmax   = max(PopObj(FrontNo==1,:),[],1);
    a      = Zmax - Z + 1e-6;
    PopObj_translated = PopObj - Z;
    PopObj_normalized = PopObj_translated./a;

    %% Select the solutions in the last front
    Last   = find(FrontNo==MaxFNo);
    Choose = true(1,length(Last));
    while sum(Choose) > N-sum(Next)
        drawnow();
        Remain  = find(Choose);
        F       = CalHV3(PopObj_normalized(Last(Remain),:),RefPoint,sum(Choose)-N+sum(Next),nSample);
        [~,del] = min(F);
        Choose(Remain(del)) = false;
    end
    Next(Last(Choose)) = true;
    % Population for next generation
    Population = Population(Next);
end